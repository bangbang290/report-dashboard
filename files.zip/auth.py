"""
auth.py
로그인 / 회원가입 폼과 세션 상태 관리.
각 페이지 맨 위에서 require_login() 을 호출하면 됩니다.

로그인 유지(새로고침해도 로그인 안 풀리게) 방식:
- 로그인 성공 시, 서버(DB)에 세션 토큰을 만들고 그 토큰을 브라우저 쿠키에 저장합니다.
- 페이지를 새로고침하면 st.session_state 는 초기화되지만, 쿠키에 저장된 토큰은 남아있으므로
  그 토큰으로 DB를 조회해서 자동으로 다시 로그인 상태를 복원합니다.
- 쿠키는 extra-streamlit-components 라는 작은 라이브러리로 다룹니다. (requirements.txt 참고)
"""

from datetime import datetime, timedelta

import streamlit as st
import extra_streamlit_components as stx

import db

COOKIE_NAME = "report_dashboard_session"


def _init_session():
    if "user" not in st.session_state:
        st.session_state["user"] = None


def _get_cookie_manager():
    # 같은 CookieManager 인스턴스를 세션 안에서 재사용 (매 rerun마다 새로 만들면 중복 컴포넌트 문제가 생길 수 있음)
    if "_cookie_manager" not in st.session_state:
        st.session_state["_cookie_manager"] = stx.CookieManager(key="report_dashboard_cookie_manager")
    return st.session_state["_cookie_manager"]


def current_user():
    _init_session()
    return st.session_state["user"]


def is_admin() -> bool:
    user = current_user()
    return bool(user) and user.get("role") == db.ROLE_ADMIN


def logout():
    token = st.session_state.get("_session_token")
    if token:
        db.delete_session(token)
    cookie_manager = _get_cookie_manager()
    try:
        cookie_manager.delete(COOKIE_NAME)
    except KeyError:
        pass  # 쿠키가 이미 없는 경우
    st.session_state["user"] = None
    st.session_state["_session_token"] = None
    st.rerun()


def _do_login(username: str, password: str):
    result = db.verify_user(username, password)
    if result and "__locked_until__" in result:
        st.error(
            f"🔒 로그인을 5회 연속 실패해서 잠시 잠겼습니다. {result['__locked_until__']} 이후 다시 시도해주세요."
        )
        return
    if not result:
        st.error("이름 또는 비밀번호가 올바르지 않습니다.")
        return

    token = db.create_session(result["username"])
    cookie_manager = _get_cookie_manager()
    cookie_manager.set(
        COOKIE_NAME, token,
        expires_at=datetime.now() + timedelta(days=db.SESSION_MAX_AGE_DAYS),
        key="set_session_cookie",
    )
    st.session_state["user"] = result
    st.session_state["_session_token"] = token
    st.rerun()


def _login_form():
    st.subheader("🔐 로그인")
    with st.form("login_form"):
        username = st.text_input("이름", help="가입할 때 등록한 로그인용 이름입니다.")
        password = st.text_input("비밀번호", type="password")
        submitted = st.form_submit_button("로그인", use_container_width=True)
    if submitted:
        _do_login(username, password)


def _signup_form():
    st.subheader("📝 최초 등록")
    st.caption("처음 접속하는 분은 여기서 이름과 비밀번호를 등록해주세요. 이후에는 로그인 탭을 이용하시면 됩니다.")
    with st.form("signup_form"):
        username = st.text_input("이름 (로그인용 계정명, 예: 홍길동)")
        department = st.text_input("부서 (선택)")
        password = st.text_input("비밀번호", type="password")
        password2 = st.text_input("비밀번호 확인", type="password")
        make_admin = False
        if not db.any_admin_exists():
            make_admin = st.checkbox("이 계정을 관리자 계정으로 등록 (최초 1회만 표시됩니다)")
        submitted = st.form_submit_button("등록하기", use_container_width=True)

    if submitted:
        if password != password2:
            st.error("비밀번호가 서로 일치하지 않습니다.")
            return
        role = db.ROLE_ADMIN if make_admin else db.ROLE_USER
        ok, msg = db.create_user(username, password, department, role)
        if ok:
            st.success(msg + " 이제 로그인 탭에서 로그인해주세요.")
        else:
            st.error(msg)


def _try_restore_session_from_cookie():
    """쿠키에 로그인 토큰이 남아있으면 자동으로 로그인 상태를 복원."""
    cookie_manager = _get_cookie_manager()
    token = cookie_manager.get(COOKIE_NAME)
    if not token:
        return
    user = db.get_session_user(token)
    if user:
        st.session_state["user"] = user
        st.session_state["_session_token"] = token


def require_login():
    """
    로그인 안 되어 있으면 (쿠키로도 복원 안 되면) 로그인/가입 폼만 보여주고
    st.stop() 으로 페이지 실행을 막음.
    """
    _init_session()
    db.init_db()

    if st.session_state["user"] is None:
        _try_restore_session_from_cookie()

    if st.session_state["user"] is not None:
        return st.session_state["user"]

    st.title("국장님 보고 진행현황")
    tab1, tab2 = st.tabs(["로그인", "최초 등록"])
    with tab1:
        _login_form()
    with tab2:
        _signup_form()
    st.stop()


def require_admin():
    """관리자 전용 페이지 맨 위에서 호출. 관리자가 아니면 안내만 보여주고 멈춤."""
    user = require_login()
    if user.get("role") != db.ROLE_ADMIN:
        st.warning("이 페이지는 관리자만 볼 수 있습니다.")
        st.stop()
    return user


def sidebar_user_info():
    user = current_user()
    if not user:
        return
    with st.sidebar:
        st.markdown(f"**{user['username']}**님 ({'관리자' if user['role'] == db.ROLE_ADMIN else '일반 사용자'})")
        if user.get("department"):
            st.caption(user["department"])
        if st.button("로그아웃", use_container_width=True):
            logout()
