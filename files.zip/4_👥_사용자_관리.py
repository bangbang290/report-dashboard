"""
pages/4_👥_사용자_관리.py
관리자가 다른 사용자의 역할(일반/관리자)을 바꾸거나, 비밀번호를 초기화해줄 수 있는 화면.
관리자만 접근 가능합니다.
"""

import secrets
import string

import streamlit as st

import db
import auth

st.set_page_config(page_title="사용자 관리", page_icon="👥", layout="wide")

db.init_db()
current = auth.require_admin()
auth.sidebar_user_info()

st.title("👥 사용자 관리")
st.caption("관리자만 볼 수 있는 화면입니다. 역할 변경 및 비밀번호 초기화 시 활동 이력에 기록됩니다.")


def _generate_temp_password(length=8):
    alphabet = string.ascii_letters + string.digits
    return "".join(secrets.choice(alphabet) for _ in range(length))


users = db.list_users()
st.caption(f"총 {len(users)}명")

for u in users:
    with st.container(border=True):
        c1, c2, c3 = st.columns([2, 2, 2])
        c1.markdown(f"**{u['username']}**" + (f" ({u['department']})" if u["department"] else ""))
        c2.markdown("👑 관리자" if u["role"] == db.ROLE_ADMIN else "일반 사용자")
        c3.caption(f"가입일: {u['created_at']}")

        b1, b2 = st.columns(2)

        # ---- 역할 변경 ----
        with b1:
            if u["role"] == db.ROLE_ADMIN:
                if st.button("일반 사용자로 강등", key=f"demote_{u['id']}"):
                    ok, msg = db.set_user_role(u["id"], db.ROLE_USER, actor=current["username"])
                    (st.success if ok else st.error)(msg)
                    if ok:
                        st.rerun()
            else:
                if st.button("관리자로 승격", key=f"promote_{u['id']}"):
                    ok, msg = db.set_user_role(u["id"], db.ROLE_ADMIN, actor=current["username"])
                    (st.success if ok else st.error)(msg)
                    if ok:
                        st.rerun()

        # ---- 비밀번호 초기화 ----
        with b2:
            reset_key = f"reset_open_{u['id']}"
            if st.button("비밀번호 초기화", key=f"reset_btn_{u['id']}"):
                st.session_state[reset_key] = True

            if st.session_state.get(reset_key):
                temp_pw = st.session_state.get(f"temp_pw_{u['id']}")
                if temp_pw is None:
                    temp_pw = _generate_temp_password()
                    st.session_state[f"temp_pw_{u['id']}"] = temp_pw

                st.info(f"임시 비밀번호: **{temp_pw}**  \n이 비밀번호를 본인에게 전달해주세요. 확정 전까지는 실제로 바뀌지 않습니다.")
                rc1, rc2 = st.columns(2)
                if rc1.button("✅ 이 비밀번호로 초기화 확정", key=f"reset_confirm_{u['id']}"):
                    ok, msg = db.reset_password(u["id"], temp_pw, actor=current["username"])
                    (st.success if ok else st.error)(msg)
                    st.session_state[reset_key] = False
                    st.session_state[f"temp_pw_{u['id']}"] = None
                if rc2.button("취소", key=f"reset_cancel_{u['id']}"):
                    st.session_state[reset_key] = False
                    st.session_state[f"temp_pw_{u['id']}"] = None
