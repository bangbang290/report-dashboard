"""
pages/2_월간_일정.py
국장님 월간 일정 등록/조회/수정/삭제 (회의, 연가, 출퇴근 등).
"""

import datetime as dt
import streamlit as st

import db
import auth
from utils import format_date_kr

st.set_page_config(page_title="국장님 월간 일정", page_icon="📅", layout="wide")

db.init_db()
user = auth.require_login()
auth.sidebar_user_info()

st.title("📅 국장님 월간 일정")

with st.expander("➕ 새 일정 등록", expanded=False):
    with st.form("add_schedule_form", clear_on_submit=True):
        c1, c2 = st.columns(2)
        with c1:
            event_name = st.text_input("일정명 (예: (11:00) 확대간부회의)")
        with c2:
            event_date = st.date_input("날짜")
        submitted = st.form_submit_button("등록", use_container_width=True)

    if submitted:
        if not event_name.strip():
            st.error("일정명을 입력해주세요.")
        else:
            db.register_schedule(event_name.strip(), event_date.isoformat(), user["username"])
            st.success("등록되었습니다.")
            st.rerun()

st.divider()

today = dt.date.today()
month_choice = st.text_input("조회할 월 (YYYY-MM, 비워두면 전체)", value=today.strftime("%Y-%m"))

items = db.list_schedule(month=month_choice.strip() if month_choice.strip() else None)
st.caption(f"총 {len(items)}건")

for it in items:
    can_edit = auth.is_admin() or it["created_by"] == user["username"]
    with st.container(border=True):
        top = st.columns([4, 2, 2, 1, 1])
        top[0].markdown(f"**{it['event_name']}**")
        top[1].markdown(format_date_kr(it["event_date"]))
        top[2].markdown(f"등록자: {it['created_by']}")

        if can_edit:
            edit_key = f"sched_edit_{it['id']}"
            confirm_key = f"sched_confirm_delete_{it['id']}"

            if top[3].button("수정", key=f"sched_edit_btn_{it['id']}"):
                st.session_state[edit_key] = not st.session_state.get(edit_key, False)
                st.session_state[confirm_key] = False

            if top[4].button("🗑️ 삭제", key=f"sched_delete_btn_{it['id']}"):
                st.session_state[confirm_key] = True
                st.session_state[edit_key] = False

            if st.session_state.get(confirm_key):
                st.warning(f"**'{it['event_name']}'** 일정을 정말 삭제하시겠습니까? 이 작업은 되돌릴 수 없습니다.")
                cc1, cc2 = st.columns(2)
                if cc1.button("✅ 삭제 확정", key=f"sched_confirm_yes_{it['id']}", use_container_width=True):
                    db.remove_schedule(it["id"], user["username"])
                    st.session_state[confirm_key] = False
                    st.success("삭제되었습니다.")
                    st.rerun()
                if cc2.button("취소", key=f"sched_confirm_no_{it['id']}", use_container_width=True):
                    st.session_state[confirm_key] = False
                    st.rerun()

            if st.session_state.get(edit_key):
                with st.form(f"sched_edit_form_{it['id']}"):
                    new_name = st.text_input("일정명", value=it["event_name"], key=f"sched_name_{it['id']}")
                    try:
                        default_date = dt.date.fromisoformat(it["event_date"])
                    except ValueError:
                        default_date = today
                    new_date = st.date_input("날짜", value=default_date, key=f"sched_date_{it['id']}")
                    save = st.form_submit_button("저장", use_container_width=True)

                if save:
                    db.edit_schedule(it["id"], new_name.strip(), new_date.isoformat(), actor=user["username"])
                    st.session_state[edit_key] = False
                    st.success("수정되었습니다.")
                    st.rerun()
