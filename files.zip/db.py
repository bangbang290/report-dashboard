"""
db.py
SQLite 데이터베이스 연결 및 스키마/CRUD 헬퍼 모음.
DB 파일은 기본적으로 이 파일과 같은 폴더의 report_dashboard.db 에 저장됩니다.

동시 접속 관련 설계:
- WAL 모드 사용: 한 사람이 쓰는 동안 다른 사람이 읽는 것까지 막히지 않도록 함.
- busy_timeout 설정: 아주 짧은 순간 여러 명이 동시에 쓰려고 하면, 에러를 즉시 던지지 않고
  최대 5초까지 기다렸다가 처리함.
- register_report / edit_report 는 "겹치는 시간 확인 + 실제 저장"을 하나의 트랜잭션(BEGIN IMMEDIATE)
  으로 묶어서, 두 사람이 동시에 같은 시간대를 등록해도 한 명만 성공하도록 함.
"""

import sqlite3
import hashlib
import os
import secrets
from datetime import datetime, timedelta
from contextlib import contextmanager

from utils import find_conflicts, suggest_next_available_time

DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "report_dashboard.db")

STATUS_OPTIONS = ["시작 전", "진행 중", "완료"]
ROLE_ADMIN = "admin"
ROLE_USER = "user"

SESSION_MAX_AGE_DAYS = 30
LOGIN_MAX_FAILS = 5
LOGIN_LOCK_MINUTES = 5


def _now():
    return datetime.now().isoformat(timespec="seconds")


@contextmanager
def get_conn():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    conn.execute("PRAGMA journal_mode = WAL")
    conn.execute("PRAGMA busy_timeout = 5000")
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()


@contextmanager
def get_conn_immediate():
    """
    쓰기 작업 하나를 '한 명씩 순서대로'만 처리하도록 즉시 쓰기 락을 거는 트랜잭션.
    같은 시간대 중복 등록 같은 동시 접속 문제를 막기 위해 사용.
    """
    conn = sqlite3.connect(DB_PATH, timeout=10)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    conn.execute("PRAGMA journal_mode = WAL")
    conn.execute("PRAGMA busy_timeout = 5000")
    conn.execute("BEGIN IMMEDIATE")
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def init_db():
    """최초 실행 시 테이블이 없으면 생성. 이미 있으면 아무 것도 하지 않음."""
    with get_conn() as conn:
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                department TEXT,
                password_hash TEXT NOT NULL,
                salt TEXT NOT NULL,
                role TEXT NOT NULL DEFAULT 'user',
                created_at TEXT NOT NULL
            )
            """
        )
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS reports (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                team_name TEXT NOT NULL,
                status TEXT NOT NULL DEFAULT '시작 전',
                scheduled_date TEXT,
                scheduled_time TEXT,
                raw_schedule_text TEXT,
                memo TEXT,
                created_by TEXT NOT NULL,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            )
            """
        )
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS monthly_schedule (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                event_name TEXT NOT NULL,
                event_date TEXT NOT NULL,
                created_by TEXT NOT NULL,
                created_at TEXT NOT NULL
            )
            """
        )
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS activity_log (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                table_name TEXT NOT NULL,
                record_id INTEGER,
                action TEXT NOT NULL,
                actor TEXT NOT NULL,
                detail TEXT,
                created_at TEXT NOT NULL
            )
            """
        )
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS sessions (
                token TEXT PRIMARY KEY,
                username TEXT NOT NULL,
                created_at TEXT NOT NULL
            )
            """
        )
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS login_attempts (
                username TEXT PRIMARY KEY,
                fail_count INTEGER NOT NULL DEFAULT 0,
                locked_until TEXT
            )
            """
        )


# ---------- 활동 이력 (감사로그) ----------

def log_activity(table_name: str, record_id, action: str, actor: str, detail: str = "", conn=None):
    """
    conn 을 넘기면 그 트랜잭션 안에서 같이 기록하고(원자적으로),
    안 넘기면 새 연결로 바로 기록함.
    """
    row = (table_name, record_id, action, actor, detail, _now())
    if conn is not None:
        conn.execute(
            "INSERT INTO activity_log (table_name, record_id, action, actor, detail, created_at) VALUES (?, ?, ?, ?, ?, ?)",
            row,
        )
    else:
        with get_conn() as c:
            c.execute(
                "INSERT INTO activity_log (table_name, record_id, action, actor, detail, created_at) VALUES (?, ?, ?, ?, ?, ?)",
                row,
            )


def list_activity(limit: int = 200):
    with get_conn() as conn:
        rows = conn.execute(
            "SELECT * FROM activity_log ORDER BY id DESC LIMIT ?", (limit,)
        ).fetchall()
    return [dict(r) for r in rows]


# ---------- 비밀번호 해시 ----------

def _hash_password(password: str, salt: str) -> str:
    return hashlib.sha256((salt + password).encode("utf-8")).hexdigest()


def create_user(username: str, password: str, department: str = "", role: str = ROLE_USER):
    username = username.strip()
    if not username or not password:
        return False, "이름과 비밀번호를 모두 입력해주세요."
    salt = secrets.token_hex(16)
    pw_hash = _hash_password(password, salt)
    now = _now()
    try:
        with get_conn() as conn:
            cur = conn.execute(
                "INSERT INTO users (username, department, password_hash, salt, role, created_at) "
                "VALUES (?, ?, ?, ?, ?, ?)",
                (username, department, pw_hash, salt, role, now),
            )
            log_activity("users", cur.lastrowid, "create", username, f"계정 생성 (역할: {role})", conn=conn)
        return True, "계정이 생성되었습니다."
    except sqlite3.IntegrityError:
        return False, "이미 존재하는 이름입니다. 다른 이름을 사용하거나 로그인해주세요."


def _is_locked_out(conn, username: str):
    row = conn.execute("SELECT * FROM login_attempts WHERE username = ?", (username,)).fetchone()
    if not row or not row["locked_until"]:
        return False, None
    locked_until = datetime.fromisoformat(row["locked_until"])
    if datetime.now() < locked_until:
        return True, locked_until
    return False, None


def verify_user(username: str, password: str):
    """
    성공하면 user row(dict)를 반환, 실패하면 None.
    5회 연속 실패하면 5분간 로그인 자체를 막음(무차별 대입 방지).
    """
    username = username.strip()
    with get_conn() as conn:
        locked, until = _is_locked_out(conn, username)
        if locked:
            return {"__locked_until__": until.strftime("%H:%M:%S")}

        row = conn.execute("SELECT * FROM users WHERE username = ?", (username,)).fetchone()
        ok = row is not None and _hash_password(password, row["salt"]) == row["password_hash"]

        if ok:
            conn.execute("DELETE FROM login_attempts WHERE username = ?", (username,))
            return dict(row)
        else:
            existing = conn.execute("SELECT * FROM login_attempts WHERE username = ?", (username,)).fetchone()
            fail_count = (existing["fail_count"] if existing else 0) + 1
            locked_until = None
            if fail_count >= LOGIN_MAX_FAILS:
                locked_until = (datetime.now() + timedelta(minutes=LOGIN_LOCK_MINUTES)).isoformat()
                fail_count = 0
            if existing:
                conn.execute(
                    "UPDATE login_attempts SET fail_count = ?, locked_until = ? WHERE username = ?",
                    (fail_count, locked_until, username),
                )
            else:
                conn.execute(
                    "INSERT INTO login_attempts (username, fail_count, locked_until) VALUES (?, ?, ?)",
                    (username, fail_count, locked_until),
                )
            return None


def user_exists(username: str) -> bool:
    with get_conn() as conn:
        row = conn.execute("SELECT 1 FROM users WHERE username = ?", (username.strip(),)).fetchone()
    return row is not None


def any_admin_exists() -> bool:
    with get_conn() as conn:
        row = conn.execute("SELECT 1 FROM users WHERE role = ?", (ROLE_ADMIN,)).fetchone()
    return row is not None


def list_users():
    with get_conn() as conn:
        rows = conn.execute("SELECT id, username, department, role, created_at FROM users ORDER BY username").fetchall()
    return [dict(r) for r in rows]


def get_user_by_id(user_id: int):
    with get_conn() as conn:
        row = conn.execute("SELECT * FROM users WHERE id = ?", (user_id,)).fetchone()
    return dict(row) if row else None


def count_admins() -> int:
    with get_conn() as conn:
        row = conn.execute("SELECT COUNT(*) AS c FROM users WHERE role = ?", (ROLE_ADMIN,)).fetchone()
    return row["c"]


def set_user_role(user_id: int, new_role: str, actor: str):
    user = get_user_by_id(user_id)
    if not user:
        return False, "존재하지 않는 사용자입니다."
    if user["role"] == ROLE_ADMIN and new_role != ROLE_ADMIN and count_admins() <= 1:
        return False, "관리자가 최소 1명은 있어야 합니다. 다른 사람을 먼저 관리자로 지정한 뒤 강등해주세요."
    with get_conn() as conn:
        conn.execute("UPDATE users SET role = ? WHERE id = ?", (new_role, user_id))
        log_activity(
            "users", user_id, "role_change", actor,
            f"{user['username']} 의 역할을 {user['role']} → {new_role} 로 변경", conn=conn,
        )
    return True, "역할이 변경되었습니다."


def reset_password(user_id: int, new_password: str, actor: str):
    user = get_user_by_id(user_id)
    if not user:
        return False, "존재하지 않는 사용자입니다."
    salt = secrets.token_hex(16)
    pw_hash = _hash_password(new_password, salt)
    with get_conn() as conn:
        conn.execute("UPDATE users SET password_hash = ?, salt = ? WHERE id = ?", (pw_hash, salt, user_id))
        conn.execute("DELETE FROM sessions WHERE username = ?", (user["username"],))  # 기존 로그인 세션 모두 무효화
        conn.execute("DELETE FROM login_attempts WHERE username = ?", (user["username"],))
        log_activity("users", user_id, "password_reset", actor, f"{user['username']} 비밀번호 초기화", conn=conn)
    return True, "비밀번호가 초기화되었습니다."


# ---------- 로그인 세션 유지 (쿠키용 토큰) ----------

def create_session(username: str) -> str:
    token = secrets.token_hex(32)
    with get_conn() as conn:
        conn.execute(
            "INSERT INTO sessions (token, username, created_at) VALUES (?, ?, ?)",
            (token, username, _now()),
        )
    return token


def get_session_user(token: str):
    """유효한 토큰이면 해당 user row(dict)를, 아니면 None을 반환."""
    if not token:
        return None
    with get_conn() as conn:
        row = conn.execute("SELECT * FROM sessions WHERE token = ?", (token,)).fetchone()
        if not row:
            return None
        created_at = datetime.fromisoformat(row["created_at"])
        if datetime.now() - created_at > timedelta(days=SESSION_MAX_AGE_DAYS):
            conn.execute("DELETE FROM sessions WHERE token = ?", (token,))
            return None
        user_row = conn.execute("SELECT * FROM users WHERE username = ?", (row["username"],)).fetchone()
    return dict(user_row) if user_row else None


def delete_session(token: str):
    if not token:
        return
    with get_conn() as conn:
        conn.execute("DELETE FROM sessions WHERE token = ?", (token,))


# ---------- 보고 진행현황 (reports) ----------

def add_report(team_name, status, scheduled_date, scheduled_time, memo, created_by, raw_schedule_text=""):
    """저장만 하는 저수준 함수 (충돌 체크 없음). 마이그레이션 스크립트 전용으로 남겨둠."""
    now = _now()
    with get_conn() as conn:
        conn.execute(
            """
            INSERT INTO reports
                (team_name, status, scheduled_date, scheduled_time, raw_schedule_text, memo, created_by, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (team_name, status, scheduled_date, scheduled_time, raw_schedule_text, memo, created_by, now, now),
        )


def get_times_for_date(date_str: str, exclude_id: int = None, conn=None):
    """20분 간격 체크용: 특정 날짜에 이미 등록된 (id, team_name, scheduled_time) 목록."""
    if not date_str:
        return []
    query = "SELECT id, team_name, scheduled_time FROM reports WHERE scheduled_date = ? AND scheduled_time IS NOT NULL"
    params = [date_str]
    if exclude_id is not None:
        query += " AND id != ?"
        params.append(exclude_id)
    if conn is not None:
        rows = conn.execute(query, params).fetchall()
        return [dict(r) for r in rows]
    with get_conn() as c:
        rows = c.execute(query, params).fetchall()
    return [dict(r) for r in rows]


def register_report(team_name, status, scheduled_date, scheduled_time, memo, created_by, min_gap=20, override=False):
    """
    새 보고 등록. 겹치는 시간 확인 + 저장을 하나의 트랜잭션으로 묶어서
    동시에 여러 명이 같은 시간대를 등록해도 한쪽만 성공하도록 함.
    반환: (성공여부, 충돌목록, 추천시간)
    """
    with get_conn_immediate() as conn:
        if scheduled_date and scheduled_time and not override:
            existing = get_times_for_date(scheduled_date, conn=conn)
            conflicts = find_conflicts(existing, scheduled_time, min_gap)
            if conflicts:
                suggested = suggest_next_available_time(existing, scheduled_time, min_gap)
                return False, conflicts, suggested

        now = _now()
        cur = conn.execute(
            """
            INSERT INTO reports
                (team_name, status, scheduled_date, scheduled_time, raw_schedule_text, memo, created_by, created_at, updated_at)
            VALUES (?, ?, ?, ?, '', ?, ?, ?, ?)
            """,
            (team_name, status, scheduled_date, scheduled_time, memo, created_by, now, now),
        )
        log_activity(
            "reports", cur.lastrowid, "create", created_by,
            f"'{team_name}' 등록 (상태: {status}, 예정: {scheduled_date or '-'} {scheduled_time or ''})",
            conn=conn,
        )
        return True, [], None


def edit_report(report_id, team_name, status, scheduled_date, scheduled_time, memo, actor, min_gap=20, override=False):
    """기존 보고 항목 수정. register_report 와 동일하게 원자적으로 충돌 체크."""
    with get_conn_immediate() as conn:
        old_row = conn.execute("SELECT * FROM reports WHERE id = ?", (report_id,)).fetchone()
        if not old_row:
            return False, [], None

        if scheduled_date and scheduled_time and not override:
            existing = get_times_for_date(scheduled_date, exclude_id=report_id, conn=conn)
            conflicts = find_conflicts(existing, scheduled_time, min_gap)
            if conflicts:
                suggested = suggest_next_available_time(existing, scheduled_time, min_gap)
                return False, conflicts, suggested

        now = _now()
        conn.execute(
            """
            UPDATE reports
            SET team_name = ?, status = ?, scheduled_date = ?, scheduled_time = ?, memo = ?, updated_at = ?
            WHERE id = ?
            """,
            (team_name, status, scheduled_date, scheduled_time, memo, now, report_id),
        )

        changes = []
        old = dict(old_row)
        new = {
            "team_name": team_name, "status": status,
            "scheduled_date": scheduled_date, "scheduled_time": scheduled_time, "memo": memo,
        }
        for field, label in [
            ("team_name", "이름"), ("status", "상태"),
            ("scheduled_date", "날짜"), ("scheduled_time", "시각"), ("memo", "비고"),
        ]:
            if (old.get(field) or "") != (new.get(field) or ""):
                changes.append(f"{label}: '{old.get(field) or ''}' → '{new.get(field) or ''}'")
        detail = "; ".join(changes) if changes else "(변경 없음)"
        log_activity("reports", report_id, "update", actor, detail, conn=conn)
        return True, [], None


def remove_report(report_id, actor):
    with get_conn() as conn:
        row = conn.execute("SELECT * FROM reports WHERE id = ?", (report_id,)).fetchone()
        if not row:
            return
        conn.execute("DELETE FROM reports WHERE id = ?", (report_id,))
        log_activity("reports", report_id, "delete", actor, f"'{row['team_name']}' 삭제됨", conn=conn)


def list_reports(status_filter=None, order_by="scheduled_date"):
    query = "SELECT * FROM reports"
    params = ()
    if status_filter and status_filter != "전체":
        query += " WHERE status = ?"
        params = (status_filter,)
    query += f" ORDER BY {order_by} IS NULL, {order_by} ASC, scheduled_time ASC"
    with get_conn() as conn:
        rows = conn.execute(query, params).fetchall()
    return [dict(r) for r in rows]


def get_report(report_id):
    with get_conn() as conn:
        row = conn.execute("SELECT * FROM reports WHERE id = ?", (report_id,)).fetchone()
    return dict(row) if row else None


# ---------- 국장님 월간 일정 (monthly_schedule) ----------

def add_schedule(event_name, event_date, created_by):
    """저장만 하는 저수준 함수 (마이그레이션 스크립트 전용)."""
    now = _now()
    with get_conn() as conn:
        conn.execute(
            "INSERT INTO monthly_schedule (event_name, event_date, created_by, created_at) VALUES (?, ?, ?, ?)",
            (event_name, event_date, created_by, now),
        )


def register_schedule(event_name, event_date, created_by):
    now = _now()
    with get_conn() as conn:
        cur = conn.execute(
            "INSERT INTO monthly_schedule (event_name, event_date, created_by, created_at) VALUES (?, ?, ?, ?)",
            (event_name, event_date, created_by, now),
        )
        log_activity("monthly_schedule", cur.lastrowid, "create", created_by, f"'{event_name}' ({event_date}) 등록", conn=conn)


def edit_schedule(schedule_id, event_name, event_date, actor):
    with get_conn() as conn:
        old_row = conn.execute("SELECT * FROM monthly_schedule WHERE id = ?", (schedule_id,)).fetchone()
        if not old_row:
            return
        conn.execute(
            "UPDATE monthly_schedule SET event_name = ?, event_date = ? WHERE id = ?",
            (event_name, event_date, schedule_id),
        )
        detail = f"'{old_row['event_name']}'({old_row['event_date']}) → '{event_name}'({event_date})"
        log_activity("monthly_schedule", schedule_id, "update", actor, detail, conn=conn)


def remove_schedule(schedule_id, actor):
    with get_conn() as conn:
        row = conn.execute("SELECT * FROM monthly_schedule WHERE id = ?", (schedule_id,)).fetchone()
        if not row:
            return
        conn.execute("DELETE FROM monthly_schedule WHERE id = ?", (schedule_id,))
        log_activity("monthly_schedule", schedule_id, "delete", actor, f"'{row['event_name']}' 삭제됨", conn=conn)


def list_schedule(month=None):
    """month: 'YYYY-MM' 형식이면 해당 월만 필터링"""
    query = "SELECT * FROM monthly_schedule"
    params = ()
    if month:
        query += " WHERE event_date LIKE ?"
        params = (f"{month}%",)
    query += " ORDER BY event_date ASC"
    with get_conn() as conn:
        rows = conn.execute(query, params).fetchall()
    return [dict(r) for r in rows]


def get_schedule_item(schedule_id):
    with get_conn() as conn:
        row = conn.execute("SELECT * FROM monthly_schedule WHERE id = ?", (schedule_id,)).fetchone()
    return dict(row) if row else None
