"""
pages/1_보고_진행현황.py
전체 이력 조회 + 새 보고 등록 + 본인이 등록한 항목(또는 관리자는 전체) 수정/삭제.
"""

import streamlit as st

import db
import auth
from utils import format_schedule_display

MIN_GAP_MINUTES = 20

st.set_page_config(page_title="보고 진행현황", page_icon="📋", layout="wide")

db.init_db()
user = auth.require_login()
auth.sidebar_user_info()

st.title("📋 보고 진행현황")


def _render_conflict_error(conflicts, suggested, verb="등록"):
    names = ", ".join(f"{c['team_name'] or '(이름 미입력)'}({c['scheduled_time']})" for c in conflicts)
    st.error(
        f"⏱️ 이미 예약된 시간({names})과 {MIN_GAP_MINUTES}분 미만으로 겹칩니다. "
        f"**{suggested}** 이후로 {verb}해주세요. (또는 아래 체크박스로 무시하고 {verb} 가능)"
    )


# ---------------- 새 보고 등록 ----------------
with st.expander("➕ 새 보고 등록", expanded=False):
    st.caption(f"⏱️ 같은 날짜에 이미 예약된 시간과 {MIN_GAP_MINUTES}분 미만으로 겹치면 자동으로 막고 다음 가능한 시간을 알려드립니다.")
    with st.form("add_report_form", clear_on_submit=False):
        c1, c2 = st.columns(2)
        with c1:
            team_name = st.text_input("팀명 / 보고자")
            status = st.selectbox("상태", db.STATUS_OPTIONS, index=0)
        with c2:
            scheduled_date = st.date_input("보고 예정일", value=None)
            scheduled_time = st.time_input("보고 예정 시각", value=None)
        memo = st.text_area("비고 (선택)", height=80)
        override_gap = st.checkbox(f"⚠️ {MIN_GAP_MINUTES}분 간격 무시하고 그래도 이 시간으로 등록")
        submitted = st.form_submit_button("등록", use_container_width=True)

    if submitted:
        if not team_name.strip():
            st.error("팀명 / 보고자를 입력해주세요.")
        else:
            date_str = scheduled_date.isoformat() if scheduled_date else None
            time_str = scheduled_time.strftime("%H:%M") if scheduled_time else None

            ok, conflicts, suggested = db.register_report(
                team_name=team_name.strip(),
                status=status,
                scheduled_date=date_str,
                scheduled_time=time_str,
                memo=memo.strip(),
                created_by=user["username"],
                min_gap=MIN_GAP_MINUTES,
                override=override_gap,
            )
            if ok:
                st.success("등록되었습니다.")
                st.rerun()
            else:
                _render_conflict_error(conflicts, suggested, verb="등록")

st.divider()

# ---------------- 필터 ----------------
filter_cols = st.columns([2, 3, 2])
with filter_cols[0]:
    status_filter = st.selectbox("상태 필터", ["전체"] + db.STATUS_OPTIONS)
with filter_cols[1]:
    search_text = st.text_input("이름 검색 (부분 일치)")

reports = db.list_reports(status_filter=status_filter)
if search_text.strip():
    reports = [r for r in reports if search_text.strip() in (r["team_name"] or "")]

st.caption(f"총 {len(reports)}건")

# ---------------- 목록 + 수정/삭제 ----------------
for r in reports:
    can_edit = auth.is_admin() or r["created_by"] == user["username"]
    with st.container(border=True):
        top = st.columns([3, 2, 2, 2, 1, 1])
        top[0].markdown(f"**{r['team_name'] or '(이름 미입력)'}**")
        top[1].markdown(r["status"])
        top[2].markdown(format_schedule_display(r["scheduled_date"], r["scheduled_time"]))
        top[3].markdown(f"등록자: {r['created_by']}")

        if can_edit:
            edit_key = f"edit_open_{r['id']}"
            confirm_key = f"confirm_delete_{r['id']}"

            if top[4].button("수정", key=f"edit_btn_{r['id']}"):
                st.session_state[edit_key] = not st.session_state.get(edit_key, False)
                st.session_state[confirm_key] = False

            if top[5].button("🗑️ 삭제", key=f"delete_btn_{r['id']}"):
                st.session_state[confirm_key] = True
                st.session_state[edit_key] = False

            if st.session_state.get(confirm_key):
                st.warning(f"**'{r['team_name'] or '(이름 미입력)'}'** 항목을 정말 삭제하시겠습니까? 이 작업은 되돌릴 수 없습니다.")
                cc1, cc2 = st.columns(2)
                if cc1.button("✅ 삭제 확정", key=f"confirm_yes_{r['id']}", use_container_width=True):
                    db.remove_report(r["id"], user["username"])
                    st.session_state[confirm_key] = False
                    st.success("삭제되었습니다.")
                    st.rerun()
                if cc2.button("취소", key=f"confirm_no_{r['id']}", use_container_width=True):
                    st.session_state[confirm_key] = False
                    st.rerun()

            if st.session_state.get(edit_key):
                with st.form(f"edit_form_{r['id']}"):
                    e1, e2 = st.columns(2)
                    with e1:
                        new_team = st.text_input("팀명 / 보고자", value=r["team_name"], key=f"team_{r['id']}")
                        new_status = st.selectbox(
                            "상태", db.STATUS_OPTIONS,
                            index=db.STATUS_OPTIONS.index(r["status"]) if r["status"] in db.STATUS_OPTIONS else 0,
                            key=f"status_{r['id']}",
                        )
                    with e2:
                        try:
                            import datetime as _dt
                            default_date = _dt.date.fromisoformat(r["scheduled_date"]) if r["scheduled_date"] else None
                        except ValueError:
                            default_date = None
                        new_date = st.date_input("보고 예정일", value=default_date, key=f"date_{r['id']}")
                        try:
                            import datetime as _dt
                            default_time = _dt.datetime.strptime(r["scheduled_time"], "%H:%M").time() if r["scheduled_time"] else None
                        except (ValueError, TypeError):
                            default_time = None
                        new_time = st.time_input("보고 예정 시각", value=default_time, key=f"time_{r['id']}")
                    new_memo = st.text_area("비고", value=r["memo"] or "", key=f"memo_{r['id']}")
                    edit_override_gap = st.checkbox(
                        f"⚠️ {MIN_GAP_MINUTES}분 간격 무시하고 그래도 이 시간으로 저장", key=f"override_{r['id']}"
                    )
                    save = st.form_submit_button("저장", use_container_width=True)

                if save:
                    new_date_str = new_date.isoformat() if new_date else None
                    new_time_str = new_time.strftime("%H:%M") if new_time else None

                    ok, conflicts, suggested = db.edit_report(
                        r["id"], new_team.strip(), new_status, new_date_str, new_time_str, new_memo.strip(),
                        actor=user["username"], min_gap=MIN_GAP_MINUTES, override=edit_override_gap,
                    )
                    if ok:
                        st.session_state[edit_key] = False
                        st.success("수정되었습니다.")
                        st.rerun()
                    else:
                        _render_conflict_error(conflicts, suggested, verb="저장")

        if r["memo"]:
            st.caption(f"📝 {r['memo']}")
